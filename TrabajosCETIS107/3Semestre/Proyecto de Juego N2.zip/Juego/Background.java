import java.awt.*;
import javax.swing.ImageIcon;

public class Background {
    private Image backgroundImage;
    private int x1, x2;
    private static final int BACKGROUND_SPEED = 5;
    
    public Background() {
        // Cargar imagen de fondo
        backgroundImage = new ImageIcon("background.jpg").getImage();  // Asegúrate de tener la imagen 'background.png'
        x1 = 0;
        x2 = 800; // El fondo tiene que moverse en dos partes
    }

    public void update() {
        x1 -= BACKGROUND_SPEED;
        x2 -= BACKGROUND_SPEED;

        // Cuando la primera parte del fondo sale de la pantalla, la reposicionamos
        if (x1 + 800 <= 0) {
            x1 = 800;
        }
        if (x2 + 800 <= 0) {
            x2 = 800;
        }
    }

    public void draw(Graphics g) {
        // Dibujar dos partes del fondo para crear un efecto de desplazamiento
        g.drawImage(backgroundImage, x1, 0, 800, 600, null);
        g.drawImage(backgroundImage, x2, 0, 800, 600, null);
    }
}