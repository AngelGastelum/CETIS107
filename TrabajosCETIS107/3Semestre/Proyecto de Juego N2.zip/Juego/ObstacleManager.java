import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class ObstacleManager {
    private ArrayList<Rectangle> pipes;
    private static final int PIPE_WIDTH = 100, PIPE_GAP = 150;
    private static final int PIPE_SPEED = 5;
    
    public ObstacleManager() {
        pipes = new ArrayList<>();
    }

    public void update() {
        ArrayList<Rectangle> newPipes = new ArrayList<>();
        for (Rectangle pipe : pipes) {
            pipe.x -= PIPE_SPEED;
            if (pipe.x + PIPE_WIDTH > 0) {
                newPipes.add(pipe);
            }
        }
        pipes = newPipes;

        if (pipes.size() == 0 || pipes.get(pipes.size() - 1).x < 500) {
            int pipeHeight = 50 + new Random().nextInt(300);
            pipes.add(new Rectangle(800, 600 - pipeHeight - PIPE_GAP, PIPE_WIDTH, pipeHeight));
            pipes.add(new Rectangle(800, 0, PIPE_WIDTH, 600 - pipeHeight - PIPE_GAP));
        }
    }

    public void draw(Graphics g) {
        for (Rectangle pipe : pipes) {
            g.setColor(Color.green);
            g.fillRect(pipe.x, pipe.y, pipe.width, pipe.height);
        }
    }

    public boolean collidesWith(Bird bird) {
        for (Rectangle pipe : pipes) {
            if (pipe.intersects(new Rectangle(100, bird.getY(), 50, bird.getHeight()))) {
                return true;
            }
        }
        return false;
    }

    public void reset() {
        pipes.clear();
    }
}