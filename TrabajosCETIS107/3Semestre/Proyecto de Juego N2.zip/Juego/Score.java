import java.awt.*;

public class Score {
    private int score;

    public Score() {
        score = 0;
    }

    public void update() {
        score++;
    }

    public void draw(Graphics g) {
        g.setColor(Color.white);
        g.setFont(new Font("Arial", Font.PLAIN, 30));
        g.drawString("Score: " + score, 700, 50);
    }

    public int getScore() {
        return score;
    }

    public void reset() {
        score = 0;
    }
}