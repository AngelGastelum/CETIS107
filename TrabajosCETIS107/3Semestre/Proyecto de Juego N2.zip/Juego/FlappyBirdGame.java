import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FlappyBirdGame extends JPanel implements ActionListener, KeyListener {
    private static final int WIDTH = 800, HEIGHT = 600;
    private Timer timer;
    private Bird bird;
    private Score score;
    private boolean gameOver, gameStarted, gamePaused;
    private Background background;
    private ObstacleManager obstacleManager;
    private JButton startButton, pauseButton, resumeButton, quitButton;
    
    public FlappyBirdGame() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.cyan);
        setFocusable(true);
        addKeyListener(this);

        bird = new Bird();
        score = new Score();
        background = new Background();
        obstacleManager = new ObstacleManager();
        
        // Configurar botones
        startButton = new JButton("Start");
        pauseButton = new JButton("Pause");
        resumeButton = new JButton("Resume");
        quitButton = new JButton("Quit");
        
        setupButtons();

        // Timer para la actualización del juego
        timer = new Timer(20, this);
        timer.start();
    }

    // Configurar botones
    private void setupButtons() {
        // Botón de inicio
        startButton.setBounds(WIDTH / 2 - 50, HEIGHT / 2, 100, 50);
        startButton.addActionListener(e -> startGame());
        startButton.setVisible(true);
        this.add(startButton);

        // Botón de pausa
        pauseButton.setBounds(WIDTH / 2 - 50, HEIGHT / 2 + 60, 100, 50);
        pauseButton.addActionListener(e -> pauseGame());
        pauseButton.setVisible(false);
        this.add(pauseButton);

        // Botón de reanudar
        resumeButton.setBounds(WIDTH / 2 - 50, HEIGHT / 2 + 120, 100, 50);
        resumeButton.addActionListener(e -> resumeGame());
        resumeButton.setVisible(false);
        this.add(resumeButton);

        // Botón de salir
        quitButton.setBounds(WIDTH / 2 - 50, HEIGHT / 2 + 180, 100, 50);
        quitButton.addActionListener(e -> System.exit(0));
        quitButton.setVisible(true);
        this.add(quitButton);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        background.draw(g);

        if (!gameStarted) {
            g.setColor(Color.white);
            g.setFont(new Font("Arial", Font.PLAIN, 50));
            g.drawString("Press SPACE to Start", 150, HEIGHT / 2);
        }

        if (gameOver) {
            g.setFont(new Font("Arial", Font.PLAIN, 50));
            g.drawString("Game Over", WIDTH / 3, HEIGHT / 3);
            g.drawString("Score: " + score.getScore(), WIDTH / 3, HEIGHT / 2);
            resumeButton.setVisible(true);
        }

        if (!gameOver && gameStarted && !gamePaused) {
            score.draw(g);
            bird.draw(g);
            obstacleManager.draw(g);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (gameStarted && !gameOver && !gamePaused) {
            bird.update();
            obstacleManager.update();
            checkCollisions();
            score.update();
            repaint();
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            if (!gameStarted) {
                gameStarted = true;
                startButton.setVisible(false);
            }
            if (gameOver) {
                resetGame();
            }
            if (gamePaused) {
                resumeGame();
            }
            bird.flap();
        }
    }

    private void startGame() {
        gameStarted = true;
        startButton.setVisible(false);
        pauseButton.setVisible(true);
        resumeButton.setVisible(false);
        gameOver = false;
    }

    private void pauseGame() {
        gamePaused = true;
        pauseButton.setVisible(false);
        resumeButton.setVisible(true);
    }

    private void resumeGame() {
        gamePaused = false;
        pauseButton.setVisible(true);
        resumeButton.setVisible(false);
    }

    private void resetGame() {
        bird.reset();
        score.reset();
        obstacleManager.reset();
        gameOver = false;
        gamePaused = false;
        pauseButton.setVisible(true);
        resumeButton.setVisible(false);
        startButton.setVisible(false);
    }

    private void checkCollisions() {
        if (bird.getY() + bird.getHeight() >= HEIGHT) {
            gameOver = true;
        }
        
        if (obstacleManager.collidesWith(bird)) {
            gameOver = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame jframe = new JFrame("Flappy Bird");
        FlappyBirdGame gamePanel = new FlappyBirdGame();
        jframe.setTitle("Flappy Bird Game");
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.add(gamePanel);
        jframe.pack();
        jframe.setVisible(true);
    }
}