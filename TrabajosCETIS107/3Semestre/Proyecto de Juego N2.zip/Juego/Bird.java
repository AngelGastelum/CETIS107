import java.awt.*;
import javax.swing.*;

public class Bird {
    private int x, y, velocity;
    private static final int GRAVITY = 1;
    private static final int JUMP_STRENGTH = -15;
    private static final int BIRD_WIDTH = 50, BIRD_HEIGHT = 50;
    private Image birdImage;

    public Bird() {
        x = 100;
        y = 300;
        velocity = 0;
        birdImage = new ImageIcon("bird.png").getImage();
    }

    public void update() {
        velocity += GRAVITY;
        y += velocity;
        if (y > 600 - BIRD_HEIGHT) {
            y = 600 - BIRD_HEIGHT;
        }
        if (y < 0) {
            y = 0;
        }
    }

    public void flap() {
        velocity = JUMP_STRENGTH;
    }

    public void draw(Graphics g) {
        g.drawImage(birdImage, x, y, BIRD_WIDTH, BIRD_HEIGHT, null);
    }

    public void reset() {
        y = 300;
        velocity = 0;
    }

    public int getY() {
        return y;
    }

    public int getHeight() {
        return BIRD_HEIGHT;
    }
}