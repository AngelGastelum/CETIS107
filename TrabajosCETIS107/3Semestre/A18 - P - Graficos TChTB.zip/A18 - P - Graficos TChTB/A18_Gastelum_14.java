import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class A18_Gastelum_14 extends JFrame {
    
    public A18_Gastelum_14() {
        setTitle("Actividad A18, Mi Dibujo");
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null); // Usamos layout nulo para posicionar manualmente las figuras
        
        // Botón salir
        JButton botonSalir = new JButton("Salir");
        botonSalir.setBounds(200, 400, 100, 30);
        botonSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        add(botonSalir);
    }

    // Método paint para dibujar las figuras
    public void paint(Graphics g) {
        super.paint(g);

        // Dibujar 2 círculos
        g.setColor(Color.RED);
        g.drawOval(210, 50, 50, 50);  // Círculo 1
        g.drawOval(200, 100, 80, 80);  // Círculo 2

        // Dibujar 2 cuadrados
        g.setColor(Color.BLUE);
        g.drawRect(215, 60, 10, 10);  // Cuadrado 1
        g.drawRect(240, 60, 10, 10);  // Cuadrado 2

        // Dibujar 2 triángulos
        g.setColor(Color.GREEN);
        int[] x1 = {100, 100, 350};
        int[] y1 = {100, 140, 200};
        g.drawPolygon(x1, y1, 3);  // Triángulo 1

        int[] x2 = {100, 100, 250};
        int[] y2 = {100, 140, 100};
        g.drawPolygon(x2, y2, 3);  // Triángulo 2

        // Texto personalizado usando drawString
        g.setColor(Color.BLACK);
        g.drawString("Homero si baila.mp3", 150, 300);

        // Nombre, grupo, fecha y actividad
        g.drawString("Angel Daniel Gastelum Rocha, 3AVP, 18/10/2024, A18", 150, 320);
    }

    public static void main(String[] args) {
        A18_Gastelum_14 ventana = new A18_Gastelum_14();
        ventana.setVisible(true);
    }
}