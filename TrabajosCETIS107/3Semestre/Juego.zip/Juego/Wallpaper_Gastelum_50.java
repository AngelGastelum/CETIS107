import java.awt.Graphics2D;
import javax.swing.ImageIcon;

public class Wallpaper_Gastelum_50 {
    private final int ancho_Fondo = 1280;
    private final int alto_Fondo = 521;
    private int x_Fondo = 0;
    private int y_Fondo = 0;
    private int x_Fondo2 = ancho_Fondo;

    private Panel_de_juego_50 panel_para_juego_50;

    public Wallpaper_Gastelum_50(Panel_de_juego_50 panel_juego_50) {
        this.panel_para_juego_50 = panel_juego_50;
    }

    public void mover() {
        x_Fondo -= 2; 
        x_Fondo2 -= 2;

        if (x_Fondo + ancho_Fondo <= 0) {
            x_Fondo = x_Fondo2 + ancho_Fondo;
        }

        if (x_Fondo2 + ancho_Fondo <= 0) {
            x_Fondo2 = x_Fondo + ancho_Fondo;
        }
    }

    public void dibujalo(Graphics2D obj_Fondo) {
        ImageIcon Obj_W_Gastelum_50 = new ImageIcon(getClass().getResource("Fondo.jpg"));
        obj_Fondo.drawImage(Obj_W_Gastelum_50.getImage(), x_Fondo, y_Fondo, ancho_Fondo, alto_Fondo, null);
        obj_Fondo.drawImage(Obj_W_Gastelum_50.getImage(), x_Fondo2, y_Fondo, ancho_Fondo, alto_Fondo, null);
    }
}