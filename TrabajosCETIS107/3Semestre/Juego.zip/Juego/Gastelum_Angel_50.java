import javax.swing.JFrame;

public class Gastelum_Angel_50{
	public static void main(String[] args) {
		
		JFrame ventana_principal_50 = new JFrame("Juego PET ");
		Panel_de_juego_50 panel_del_juego_50 = new Panel_de_juego_50();
		ventana_principal_50.add(panel_del_juego_50);
		ventana_principal_50.setSize(1366,521);
		ventana_principal_50.setLocationRelativeTo(null);
		ventana_principal_50.setVisible(true);
		ventana_principal_50.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		while(!panel_del_juego_50.GameFinished){
			panel_del_juego_50.repaint();
			try{
				Thread.sleep(5);
			}catch(InterruptedException ex){
				System.out.println("OH NO!!!, ALGO OCURRIO MAL. FAVOR DE REINICIAR EL PROGRAMA.");
			}
		}

	}
}