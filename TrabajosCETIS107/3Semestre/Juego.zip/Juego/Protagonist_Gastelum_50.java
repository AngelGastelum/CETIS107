import java.awt.Graphics2D;
import javax.swing.ImageIcon;
import java.awt.event.KeyEvent;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;

public class Protagonist_Gastelum_50{

		Area AreaDeUser;
		int ancho_Prota= 75;
		int alto_Prota= 75;
		int ancho_Explosion= 75;
		int alto_Explosion= 75;
		int x_Player= 75;
		int y_Player= 300;
		int x_Aux=0;
		int y_Aux=0;
		boolean Player_Jump = false;
		boolean Player_Up = false;
		boolean Player_Down = false;

	private Panel_de_juego_50 panel_para_juego_50;
	public Protagonist_Gastelum_50(Panel_de_juego_50 panel_de_juego_50){
		this.panel_para_juego_50 = panel_de_juego_50;
	}
	
	public void dibujalo(Graphics2D g){
		ImageIcon Obj_P_Gastelum_50= new ImageIcon(getClass().getResource("Prota.png"));
		g.drawImage(Obj_P_Gastelum_50.getImage(), x_Player, y_Player, ancho_Prota, alto_Prota, null);
	
	} 
	public void move(){
		if (x_Player + x_Aux > 2 && x_Player + x_Aux < panel_para_juego_50.getWidth() - 680)
			x_Player = x_Player + x_Aux;
		if(Player_Jump){
			if(y_Player == 300){
				Player_Up = true;
				y_Aux=-2;
				Player_Down = false;
				}
			if(y_Player == 150){
				Player_Down = true;
				y_Aux=3;
				Player_Up = false;
			}
			if(Player_Up){
				y_Player = y_Player + y_Aux;
			}
			if(Player_Down){
				y_Player = y_Player + y_Aux;
				if(y_Player == 300){
					Player_Jump=false;
				}
			}
			}
		}

		public void KeyPressed(KeyEvent e){
			if(e.getKeyCode() == KeyEvent.VK_SPACE){
				Player_Jump=true;
			}
			if(e.getKeyCode() == KeyEvent.VK_RIGHT){
				x_Aux = x_Aux + 1;
			}
			if(e.getKeyCode() == KeyEvent.VK_LEFT){
				x_Aux = x_Aux - 1;
			}
		}
		public Area take_area(){
			Ellipse2D ContornoFigura=new Ellipse2D.Double(x_Player, y_Player, ancho_Prota, alto_Prota);
			AreaDeUser=new Area(ContornoFigura);
			return AreaDeUser;
		}


	}