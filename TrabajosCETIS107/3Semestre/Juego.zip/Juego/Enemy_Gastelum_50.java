import java.awt.Graphics2D;
import javax.swing.ImageIcon;
import java.awt.event.KeyEvent;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;

public class Enemy_Gastelum_50{

	Area AreaDelGato;

	int ancho_Gato= 85;
	int alto_Gato= 85;

	int x_Gato= 1200;
	int y_Gato= 300;

	int x_Aux=-5;
	int y_Aux=0;

	private Panel_de_juego_50 panel_para_juego_50;
	public Enemy_Gastelum_50(Panel_de_juego_50 panel_de_juego_50, int vr_Aux){
		this.panel_para_juego_50 = panel_de_juego_50;
		x_Aux= vr_Aux;
	}
	public void dibujalo(Graphics2D g){
	ImageIcon Obj_E_Gastelum_50= new ImageIcon(getClass().getResource("Gato.png"));
	g.drawImage(Obj_E_Gastelum_50.getImage(), x_Gato, y_Gato, ancho_Gato, alto_Gato, null);
	}
	public boolean Crash(){
		Area AreaDeUser = new Area();
		AreaDeUser = panel_para_juego_50.Obj_P_Gastelum_50.take_area();
		AreaDeUser.intersect(take_area());
		return !AreaDeUser.isEmpty();

	}
	public Area take_area(){
	Ellipse2D ContornoFigura=new Ellipse2D.Double(x_Gato, y_Gato, ancho_Gato, alto_Gato);
	AreaDelGato=new Area(ContornoFigura);
	return AreaDelGato;
	}
	public void move(){
		if(x_Gato<=-85){
			panel_para_juego_50.points++;
			x_Gato=1366;
		}
		else
		{
			if(Crash()){
				panel_para_juego_50.GameOver();
			}else{
				x_Gato =x_Gato + x_Aux;
			}
		}
	}
}