import javax.swing.JPanel;

import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.applet.AudioClip;
import java.applet.Applet;
import java.awt.*;
import javax.swing.ImageIcon;

public class Panel_de_juego_50 extends JPanel{
		Wallpaper_Gastelum_50 Obj_W_Gastelum_50 = new Wallpaper_Gastelum_50(this);
		Protagonist_Gastelum_50 Obj_P_Gastelum_50=new Protagonist_Gastelum_50(this);
		Enemy_Gastelum_50 Obj_E_Gastelum_50=new Enemy_Gastelum_50(this,-3);
		Enemy_Gastelum_50 Obj2_E_Gastelum_50=new Enemy_Gastelum_50(this,-4);

		public int points=0;
		public boolean GameFinished=false;;

		URL JumpSoundDirection;
		AudioClip JumpSound;
		URL CrashSoundDirection;
		AudioClip CrashSound;
		URL FondoMusicDirection;
		AudioClip FondoMusic;

		public Panel_de_juego_50(){
			JumpSoundDirection=getClass().getResource("salto.wav");
			JumpSound=Applet.newAudioClip(JumpSoundDirection);

			CrashSoundDirection=getClass().getResource("choque.wav");
			CrashSound=Applet.newAudioClip(CrashSoundDirection);


			addKeyListener(new KeyListener()  {

                            @Override
                            public void keyTyped(KeyEvent e) {
                                throw new UnsupportedOperationException("Not supported yet.");
                            }

                            @Override
                            public void keyPressed(KeyEvent e) {
                                if(e.getKeyCode()==KeyEvent.VK_SPACE){
                                JumpSound.play();
								Obj_P_Gastelum_50.KeyPressed(e);
								}
								if(e.getKeyCode()==KeyEvent.VK_LEFT || e.getKeyCode()==KeyEvent.VK_RIGHT){
								Obj_P_Gastelum_50.KeyPressed(e);
								}
                            }

                            @Override
                            public void keyReleased(KeyEvent e) {
                        }
			} );
			setFocusable(true);
		}
		
		@Override
		public void paintComponent(Graphics obj_imag){
			super.paintComponent(obj_imag);
			Graphics2D obj_imag_2D = (Graphics2D) obj_imag;

		 	dibujar(obj_imag_2D);
		 	Texts(obj_imag_2D);
		}
	public void dibujar(Graphics2D g){
		Obj_W_Gastelum_50.dibujalo(g);
		Obj_P_Gastelum_50.dibujalo(g);
		Obj_E_Gastelum_50.dibujalo(g);
		if(points>=5){
			Obj2_E_Gastelum_50.dibujalo(g);
			Obj2_E_Gastelum_50.move();
		}
		movimientos();
	}

	public void movimientos(){
		Obj_W_Gastelum_50.mover();
		Obj_P_Gastelum_50.move();
		Obj_E_Gastelum_50.move();
	}

	public void GameOver(){
		CrashSound.play();
		GameFinished=true;
	}

	public void Texts(Graphics2D g){
		Font lyrics=new Font("ArialBlack", Font.BOLD, 50);
		g.setFont(lyrics);
		g.setColor(Color.WHITE);
		g.drawString("Puntos: "+ points, 980, 75);	
		Font lyrics3=new Font("ArialBlack", Font.BOLD, 50);
		g.setFont(lyrics3);
		g.setColor(Color.RED);
		g.drawString("JUEGO PROYECTO PET ", 400, 150 );

		if(GameFinished){
			Font lyrics4=new Font("ArialBlack", Font.BOLD, 50);
			g.setFont(lyrics4);
			g.setColor(Color.RED);
			g.drawString("GAME OVER", 560, 260 );
			g.drawString("Perdiste tontobobolon", 450, 220 );
			Font Lyrics2=new Font("ArialBlack", Font.BOLD, 25);
			g.setFont(Lyrics2);
			g.setColor(Color.GREEN);
			g.drawString("Gastelum Rocha Angel Daniel - 50 - 3AVP ", 20, 50 );
			g.drawString("Te Reciclaron! - Proyecto pec", 20, 20 );
		}
	}
}